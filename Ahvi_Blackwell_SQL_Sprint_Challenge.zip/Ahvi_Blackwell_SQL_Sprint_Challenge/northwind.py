import sqlite3 

con = sqlite3.connect('northwind_small.sqlite3')
cur = con.cursor()

# curs.execute("SELECT name FROM sqlite_master WHERE 
# type='table' ORDER BY
# name").fetchall()
# [('Category',), ('Customer',), ('CustomerCustomerDemo',),
#  ('CustomerDemographic',), ('Employee',), ('EmployeeTerritory',), ('Order',),
# ('OrderDetail',), ('Product',), ('Region',), ('Shipper',), ('Supplier',),
# ('Territory',)]


top_products = cur.execute('SELECT ProductName, UnitPrice FROM PRoduct \
ORDER BY UnitPrice DESC LIMIT 10').fetchall()
print(top_products)

### Q: What are the ten most expensive items (per unit price) in the database?

# Top 10 Products
"""[('Queso Cabrales',), ('NuNuCa Nuß-Nougat-Creme',), 
    ('Schoggi Schokolade',), ('Boston Crab Meat',), 
    ('Valkoinen suklaa',), ('Gnocchi di nonna Alice',), 
    ('Wimmers gute Semmelknödel',), ('Outback Lager',)
    ('Chang',), ('Aniseed Syrup',)]
"""
# Q: What is the average age of an employee at the time of their hiring?
avg_age = cur.execute('SELECT avg(HireDate -BirthDate) \
FROM Employee').fetchall()
print(avg_age[0][0])

# A: 37 Yrs Old
""" Answer: 37.22222222222222
"""

# Q: (Stretch) How does the average age of employee at hire vary by city?
# A: Come Back To When You Have Time

supply = cur.execute('SELECT ProductName, UnitPrice, CompanyName \
FROM Product \
INNER JOIN Supplier on Supplier.Id = Product.SupplierID \
ORDER BY UnitPrice DESC LIMIT 10').fetchall()
print(supply)

categ = cur.execute('SELECT CategoryName, COUNT(DISTINCT Product.Id) \
FROM Product \
INNER JOIN Category on Category.Id = Product.CategoryID \
GROUP BY CategoryName \
ORDER BY COUNT(DISTINCT Product.Id) DESC \
LIMIT 1 \
').fetchall()
print(categ[0][0])

"""CONFECTIONS:"""
con.close()
