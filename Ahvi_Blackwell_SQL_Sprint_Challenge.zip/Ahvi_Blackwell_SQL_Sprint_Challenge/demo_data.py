import sqlite3

# Part 1 - Making And Populating A Database
con = sqlite3.connect('demo_data.sqlite3')
cur = con.cursor()
cur.execute('CREATE TABLE IF NOT EXISTS demo ( \
s TEXT NOT NULL, \
x INT NOT NULL, \
y INT NOT NULL \
)')
cur.execute("INSERT INTO demo(s,x,y) \
VALUES \
('g', 3, 9), \
('v', 5, 7), \
('f', 8, 7)")
test = cur.execute('SELECT * FROM demo').fetchall()
print(test)

con.commit()
rows = cur.execute('SELECT COUNT(*) FROM demo').fetchall()
print(rows[0][0])

five_up = cur.execute('SELECT COUNT(*) FROM demo WHERE x > 4 AND y > 4').fetchall()
print(five_up[0][0])

unique = cur.execute('SELECT COUNT(DISTINCT y) FROM demo').fetchall()
print(unique[0][0])

con.close()